/*
* wyshell.c
* Author: Clayton Brown
* Date: Apr 18, 2023
*
* COSC 3750, Homework 9
*
* This code is used to simulate the experience of using
* a shell. At the moment, the user is capable of using
* basic commands, but is not allowed to redirect output
* in any way.
*
*/


#include<stdio.h>
#include<string.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>
#include<dirent.h>
#include<errno.h>
#include <stdlib.h>
#include <sys/wait.h>
#include"wyscanner.h"
#include"command.h"

int main(){
    // Define my variables
    char input[256];
    struct command currentCommand[20];
    char *tokens[]={ "QUOTE_ERROR", "ERROR_CHAR", "SYSTEM_ERROR",
                "EOL", "REDIR_OUT", "REDIR_IN", "APPEND_OUT",
                "REDIR_ERR", "APPEND_ERR", "REDIR_ERR_OUT", "SEMICOLON",
                "PIPE", "AMP", "WORD" };
    int commandChecker=0;
    int commandNeeded=1;
    int redirectInput=0;
    int redirectOutput=0;
    int redirectError=0;
    int appendOutput=0;
    int appendError=0;
    int errToOutput=0;
    int error=0;
    int symbolNeeded=0;
    int stringNeeded=1;
    int previousChar=0;
    int argCounter=0;
    int commCounter=0;
    int acceptArgs=1;
    int ampExists=0;
    int rtn=1;
    int fID=0;

    // This while loop repeats until the user quits the shell
    while(1){
      // Reset all my variables everytime the loop repeats
      stringNeeded=0;
      commandNeeded=1;
      commandChecker=0;
      redirectInput=0;
      redirectOutput=0;
      redirectError=0;
      appendOutput=0;
      appendError=0;
      errToOutput=0;
      symbolNeeded=0;
      error=0;
      previousChar=0;
      argCounter=0;
      commCounter=0;
      acceptArgs=1;
      ampExists=0;
      for (int j = 0; j < 20; j++){
        strncpy(currentCommand[j].commandName, "", 200);
        for (int i = 0; i < 16; i++){
            strncpy(currentCommand[j].arguments[i], "", 200);
        }
      }

      // Get input fromt the user and store it
      int testChecker=0;
      strncpy(input, "", 256);

      printf("$> ");
      fgets(input, 256, stdin);

      // If the user is done with the input, then exit
      if (feof(stdin)){
        printf("\n");
        rtn =1;
        int zombieStatus;
        while (rtn>0){
            rtn=waitpid(-1, &zombieStatus, WNOHANG);
        }
        commCounter=0;
        return 0;
      }

      testChecker=parse_line(input);
      // This loop will go through every entry in the input
      while (testChecker != EOL){
        previousChar=testChecker;
        switch(testChecker) {
          // This case handles strings, and decides if they are args or comms
          case WORD:
            if (symbolNeeded==1){
                fprintf(stderr, "Error: Expected a special key, not a string\n");
                error=1;
                break;                
            }
            if (stringNeeded==1){
                symbolNeeded=1;
            }
            if (commandChecker==0){
              //printf(":--: %s\n",lexeme);
              commandChecker=1;
              commandNeeded=0;
              commCounter=commCounter+1;
              strncpy(currentCommand[commCounter].commandName, lexeme, 200);
              strncpy(currentCommand[commCounter].arguments[0], lexeme, 200);
            }
            else{
              if (acceptArgs==1){
                  argCounter=argCounter+1;
                  strncpy(currentCommand[commCounter].arguments[argCounter], 
                           lexeme, 200);
              }
            }
            stringNeeded=0;
            break;

          case AMP:
            if (commandChecker==0)
            {
                fprintf(stderr, "Error: & is not allowed before command\n");
                error=1;
                break;
            }
            if (stringNeeded==1)
            {
                fprintf(stderr, "Error: Was expecting argument, not &\n");
                error=1;
                break;
            }
            ampExists=1;
            //printf(" &\n");
            break;

          // This case handles pipes
          case PIPE:
            if (commandChecker==0)
            {
                fprintf(stderr, "Error: Pipe is not allowed before command\n");
                error=1;
                break;
            }
            if (redirectOutput==1)
            {
                fprintf(stderr, "Error: Already redirected output\n");
                error=1;
                break;
            }
            if (commandNeeded==1)
            {
                fprintf(stderr, "Error: Command is needed.\n");
                error=1;
                break;
            }
            if (stringNeeded==1)
            {
                fprintf(stderr, "Error: Was expecting argument, not |\n");
                error=1;
                break;
            }
            stringNeeded=0;
            commandChecker=0;
            commandNeeded=1;
            redirectInput=1;
            redirectOutput=0;
            redirectError=0;
            appendOutput=0;
            appendError=0;
            errToOutput=0;
            error=0;
            acceptArgs=1;
            symbolNeeded=0;
            currentCommand[commCounter].argCount=argCounter;
            argCounter=0;

           // printf(" |  \n");
            commandChecker=0;
            break;


          // This case handles semicolons
          case SEMICOLON:
            if (commandChecker==0)
            {
                fprintf(stderr, "Error: Semicolon is not allowed before command\n");
                error=1;
                break;
            }
            if (stringNeeded==1)
            {
                fprintf(stderr, "Error: Was expecting argument, not ;\n");
                error=1;
                break;
            }
            stringNeeded=0;
            commandChecker=0;
            commandNeeded=1;
            redirectInput=0;
            redirectOutput=0;
            redirectError=0;
            appendOutput=0;
            appendError=0;
            errToOutput=0;
            symbolNeeded=0;
            error=0;
            acceptArgs=1;
            currentCommand[commCounter].argCount=argCounter;
            argCounter=0;
            ampExists=0;

           // printf(" ;\n");
            commandChecker=0;
            break;


          // This case handles the redirection of input
          case REDIR_IN:
            if (stringNeeded==1)
            {
                fprintf(stderr, "Error: Was expecting argument, not <\n");
                error=1;
                break;
            }
            if (commandNeeded==1)
            {
                fprintf(stderr, "Error: Command is needed.\n");
                error=1;
                break;
            }
            if (redirectInput==0){
                redirectInput=1;
                stringNeeded=1;
                symbolNeeded=0;
                acceptArgs=0;
             //   printf(" <\n");
            }
            else{
                fprintf(stderr, "Error: Already declared a redirection of input\n");
                error=1;
                break;
            }
            break;


          // This case handles the redirection of output
          case REDIR_OUT:
            if (stringNeeded==1)
            {
                fprintf(stderr, "Error: Was expecting argument, not >\n");
                error=1;
                break;
            }
            if (commandNeeded==1)
            {
                fprintf(stderr, "Error: Command is needed.\n");
                error=1;
                break;
            }
            if (redirectOutput==0){
                redirectOutput=1;
                stringNeeded=1;
                symbolNeeded=0;
                acceptArgs=0;
               // printf(" >\n");
            }
            else{
                fprintf(stderr, "Error: Already declared a redirection of output\n");
                error=1;
                break;
            }
            break;


          // This case handles the redirection of error output
          case REDIR_ERR_OUT:
            if (stringNeeded==1)
            {
                fprintf(stderr, "Error: Was expecting argument, not 2>&1\n");
                error=1;
                break;
            }
            if (commandNeeded==1)
            {
                fprintf(stderr, "Error: Command is needed.\n");
                error=1;
                break;
            }
            if (errToOutput==0){
                errToOutput=1;
                symbolNeeded=0;
                acceptArgs=0;
               // printf(" 2>&1\n");
            }
            else{
                fprintf(stderr, "Error: Already declared a redirection of error output\n");
                error=1;
                break;
            }
            break;


          // This case handles the redirection of errors
          case REDIR_ERR:
            if (stringNeeded==1)
            {
                fprintf(stderr, "Error: Was expecting argument, not 2>\n");
                error=1;
                break;
            }
            if (commandNeeded==1)
            {
                fprintf(stderr, "Error: Command is needed.\n");
                error=1;
                break;
            }
            if (redirectError==0){
                redirectError=1;
                stringNeeded=1;
                symbolNeeded=0;
                acceptArgs=0;
               // printf(" 2>\n");
            }
            else{
                fprintf(stderr, "Error: Already declared a redirection of error\n");
                error=1;
                break;
            }
            break;


          // This case handles appending to the output
          case APPEND_OUT:
            if (stringNeeded==1)
            {
                fprintf(stderr, "Error: Was expecting argument, not >>\n");
                error=1;
                break;
            }
            if (commandNeeded==1)
            {
                fprintf(stderr, "Error: Command is needed.\n");
                error=1;
                break;
            }
            if (appendOutput==0){
                appendOutput=1;
                stringNeeded=1;
                symbolNeeded=0;
                acceptArgs=0;
               // printf(" >>\n");
            }
            else{
                fprintf(stderr, "Error: Already declared an output append\n");
                error=1;
                break;
            }
            break;


          // This case handles appending to error
          case APPEND_ERR:
            if (stringNeeded==1)
            {
                fprintf(stderr, "Error: Was expecting argument, not 2>>\n");
                error=1;
                break;
            }
            if (commandNeeded==1)
            {
                fprintf(stderr, "Error: Command is needed.\n");
                error=1;
                break;
            }
            if (appendError==0){
                appendError=1;
                stringNeeded=1;
                symbolNeeded=0;
                acceptArgs=0;
               // printf(" 2>>\n");
            }
            else{
                fprintf(stderr, "Error: Already declared an error append\n");
                error=1;
                break;
            }
            break;


          // This checks to see if it's an unknown character/error
          case ERROR_CHAR:
            printf("ERROR: %d: %s\t =%d\n is not recognized\n",
                    testChecker,tokens[testChecker%96],error_char);
            error=1;
            break;
          case QUOTE_ERROR:
            error=1;
            fprintf(stderr, "Error: Error reading in quotes\n");
            break;
          case SYSTEM_ERROR:
            fprintf(stderr, "SYSTEM ERROR\n");
            return 0;
          default:
            printf("ERROR: %d: %s\n is unknown\n",testChecker,tokens[testChecker%96]);
        }
 
        // If there was an error, quit without printing EOL
        if (error==1)
            break;
        testChecker=parse_line(NULL);
        if ((testChecker!=EOL && previousChar==AMP) 
                        && (testChecker!=SEMICOLON && previousChar==AMP)){
            fprintf(stderr, "Error: & must come last in command\n");
            break;
        }
        // If it's the end of the string, make sure all keys have arguments
        if (testChecker == EOL || testChecker == SEMICOLON){
            if (stringNeeded==1)
            {
                fprintf(stderr, "Error: No argument given for special key\n");
                break;
            }
            if (commandNeeded==1 && previousChar != SEMICOLON)
            {
                fprintf(stderr, "Error: Command is needed.\n");
                break;
            }
            currentCommand[commCounter].argCount=argCounter;

          // This goes through all the commands on the line
          for (int j=1; j<=commCounter; j++){
              int processID=0;
              // Fork the process
              processID=fork();
              fID=processID;
              // If we're the child, execute the command using execvp
              if (processID==0){
                  int testChecker=0;
                  char **Answers = calloc(11, sizeof(char*));
                  // Set aside space for arguments
                  for(int i = 0 ; i < 11 ; i++)
                  {
                      Answers[i] = calloc(1,
                               sizeof(char)*currentCommand[j].argCount+1); 
                      Answers[i]= currentCommand[j].arguments[i];
                  }
                  Answers[currentCommand[j].argCount+1]=NULL;
                  testChecker=execvp(currentCommand[j].commandName, Answers);
                  if (testChecker==-1){
                      fprintf(stderr, "ERROR: Given command doesn't exist\n");
                      return 1;
                  }
              }
              // If in the parent, wait for the children (if possible)
              else{
                  // int status;
                  if (ampExists==0){
                      waitpid(processID, NULL, 0);
                  }
              }
          }
        // Look through all possible children and close whichever ones I can
        rtn =1;
        int zombieStatus;
        if (fID!=0){
            while (rtn>0){
                rtn=waitpid(-1, &zombieStatus, WNOHANG);
            //    if (rtn>0)
            //        fprintf(stderr, "Job has completed\n");
            //    if (rtn==0)
            //        fprintf(stderr, "Job is still processing\n");
            }
        }
        commCounter=0;
        }
      }
    }
}
